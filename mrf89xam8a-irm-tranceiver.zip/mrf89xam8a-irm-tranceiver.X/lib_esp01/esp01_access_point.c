/*
 * Access point
 * 
 * Af: Karsten R. S�rensen
 * 
 * Der skal laves en AP som kan tilsluttes fra mobil, PC l. lign. enhed
 * N�r AP er opsat og der kan tilg�es via ekstern enhed, skal der startes en 
 * server som kan give en hjemmeside, som udskriver loggen fra termometer
 * 
 * Ekstra opgave: 
 * Der laves en mulighed for at t�nde og slukke en lysdiode
 * 
 * Ekstra opgave: 
 * Der laves mulighed for at l�se fra en real-time clock
 * 
 * Ekstra opgave:
 * Der laves mulighed for at indstille uret fra en hjemmeside.
 */

#include "../mcc_generated_files/mcc.h"
