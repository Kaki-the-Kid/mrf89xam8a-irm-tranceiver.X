/* 
 * File:   access_point.h
 * Author: krs
 *
 * Created on August 29, 2019, 4:05 PM
 */

#ifndef ACCESS_POINT_H
#define	ACCESS_POINT_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ACCESS_POINT_H */

