/* 
 * File:   esp01_client_lib.h
 * Author: krs
 *
 * Created on August 29, 2019, 12:06 PM
 */

#ifndef ESP01_CLIENT_LIB_H
#define	ESP01_CLIENT_LIB_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ESP01_CLIENT_LIB_H */

