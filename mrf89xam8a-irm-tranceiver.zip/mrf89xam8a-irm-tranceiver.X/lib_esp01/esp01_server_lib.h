/* 
 * File:   esp01_server_lib.h
 * Author: krs
 *
 * Created on August 29, 2019, 12:03 PM
 */

#ifndef ESP01_SERVER_LIB_H
#define	ESP01_SERVER_LIB_H

/*
 * Prototypes
 */

void writeHTTPheader(void);

#endif	/* ESP01_SERVER_LIB_H */

