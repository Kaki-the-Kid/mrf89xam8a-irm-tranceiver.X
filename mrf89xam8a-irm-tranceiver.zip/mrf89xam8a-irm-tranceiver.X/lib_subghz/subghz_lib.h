/* 
 * File:   subghz_lib.h
 * Author: krs
 *
 * Created on August 29, 2019, 12:07 PM
 */

#ifndef SUBGHZ_LIB_H
#define	SUBGHZ_LIB_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* SUBGHZ_LIB_H */

