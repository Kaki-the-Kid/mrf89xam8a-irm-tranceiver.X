/* 
 * File:   i2c_lib.h
 * Author: krs
 *
 * Created on August 29, 2019, 4:47 PM
 */

#ifndef I2C_LIB_H
#define	I2C_LIB_H

#ifdef	__cplusplus
extern "C" {
#endif



    SSP1CON2bits_t
#ifdef	__cplusplus
}
#endif

#endif	/* I2C_LIB_H */

