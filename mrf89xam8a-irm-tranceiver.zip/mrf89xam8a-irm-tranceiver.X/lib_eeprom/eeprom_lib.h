/* 
 * File:   eeprom_lib.h
 * Author: krs
 *
 * Created on August 29, 2019, 12:01 PM
 */

#ifndef EEPROM_LIB_H
#define	EEPROM_LIB_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* EEPROM_LIB_H */

